package com.algaworks.ecommerce.model;

public enum StatusPagamento {

    PROCESSANDO,
    CANCELADO,
    RECEBIDO
}
