package com.algaworks.ecommerce.model;

public enum SexoCliente {

    MASCULINO,
    FEMININO
}
