package com.algaworks.ecommerce.model;

public enum StatusPedido {

    AGUARDANDO,
    CANCELADO,
    PAGO
}
