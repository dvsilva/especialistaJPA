package com.algaworks.ecommerce.model;

public enum SexoCliente {

    FEMININO,
    MASCULINO
}
